import "./App.css";
import AppRouter from "./Router/AppRouter";

function App() {
  return (
    <div className="App">
      <AppRouter />
    </div>
  );
}
export default App;
