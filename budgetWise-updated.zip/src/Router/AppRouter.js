import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import MainScreen from "../Screens/MainScreen/MainScreen";
// import CalculatorBack from "../Components/calculatorBack/calculatorBack";
import CostCalculator from "../Screens/costCalculate/costCalculator";
import EmailScreen from "../Screens/EmailScreen/EmailScreen";
import CostResult from "../Screens/CostResult/CostResult";
import InteractiveCalculator from "../Screens/InteractiveCalculator/InteractiveCalculator";

const AppRouter = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MainScreen />} />
        <Route path="/cost-calculate" element={<CostCalculator />} />
        {/* <Route path="/email-to-cost" element={<EmailScreen />} /> */}
        <Route path="/cost-interview-result" element={<CostResult />} />
        <Route path="/interactive-calculator" element={<InteractiveCalculator />} />
      </Routes>
    </Router>
  );
};

export default AppRouter;
