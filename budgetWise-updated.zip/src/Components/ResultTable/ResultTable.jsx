import React from 'react'
import './table.css'

const ResultTable = ({ locationData }) => {
  return (
    <div className="tableContainer">
      <table className="resultTable">
        <thead>
          <tr>
            <th></th>
            <th>Without BudgetWise</th>
            <th>With BudgetWise's AI</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Cost Per Interview</td>
            <td>${locationData ? locationData.totalCostPerInterview : 0}</td>
            <td>
              <div className="rsltMain">
                <p>
                  {' '}
                  <del> ${locationData?.totalCostPerInterview}</del>
                </p>
                <p>${locationData?.TalenyaCostPerInterview}</p>
                <p>
                  (Save {locationData?.savingPercentagePerInterviewPerJob}%)
                </p>
              </div>
            </td>
          </tr>
          <tr>
            <td>Cost Per Job (Sourcing)</td>
            <td>
              $
              {locationData
                ? locationData.costPerRecruiterPerJob
                    .toString()
                    .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                : 0}
            </td>
            <td>
              <div className="rsltMain">
                <p>
                  <del>
                    {' '}
                    $
                    {locationData?.costPerRecruiterPerJob
                      .toString()
                      .replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  </del>
                </p>
                <p>${locationData?.TalenyaSourcingCostPerJob}</p>
                <p>(Save {locationData?.SavingPerJobPercentageWithTalenya}%)</p>
              </div>
            </td>
          </tr>
          <tr>
            <td>Company Annual Sourcing Cost</td>
            <td>
              $
              {locationData
                ? locationData.companyAnnualSourcingCost
                    .toString()
                    .replace(/\B(?=(\d{3})+(?!\d))/g, ',')
                : 0}
            </td>
            <td>
              <div className="rsltMain">
                <p>
                  ${' '}
                  <del>
                    {locationData?.companyAnnualSourcingCost
                      .toString()
                      .replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  </del>
                </p>
                <p>
                  $
                  {locationData?.AnnualSourcingCostWithTalenya.toString().replace(
                    /\B(?=(\d{3})+(?!\d))/g,
                    ',',
                  )}
                </p>
                <p>
                  (Save{' '}
                  {locationData?.savingPercent >= 0 ||
                  locationData?.savingPercent <= 0
                    ? locationData?.savingPercent
                    : 0}
                  %)
                </p>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}

export default ResultTable
