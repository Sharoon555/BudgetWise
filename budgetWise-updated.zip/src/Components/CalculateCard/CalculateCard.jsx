import React, { useState } from 'react'
import arrow from '../../assets/Group 5423.png'
import info from '../../assets/Info.png'
import Slider from '@mui/material/Slider'
import { Link, useNavigate } from 'react-router-dom'
import Tooltip from '@mui/material/Tooltip'
import Arrow from '../../assets/Arrow.png'
import './calculateCard.css'

function valueLabelFormat(val, value, unit) {
  return `${val}${value}${unit}`
}

const CalculateCard = ({
  inputObject,
  onChangeFunction,
  handleSubmit,
  showFields,
  showButton,
  arrowImage,
  children,
  classname,
  className2,
  errorMsg,
  roleDefault,
  numOfInterviewDefault,
  percentageDefault,
  linkedinDefault,
}) => {
  return (
    <div className={`calcCardContainer ${classname}`}>
      <div className="calcCardSection">
        <div className={`calcCardCon ${className2}`}>
          {arrowImage ? (
            <div className="arrowImg">
              <img src={arrow} alt="..." />
            </div>
          ) : null}
          <div className="calcForm">
            <form onSubmit={handleSubmit}>
              <div className="formFields">
                <p>
                  1. The average number of new roles, per recruiter per month
                </p>
                <div className="rangeSlider">
                  <p className="rangeVals">0</p>
                  <Slider
                    aria-label="Always visible"
                    defaultValue={roleDefault}
                    step={1}
                    min={0}
                    max={20}
                    name="roles"
                    valueLabelFormat={valueLabelFormat(
                      '',
                      inputObject.roles,
                      '',
                    )}
                    valueLabelDisplay="on"
                    size="small"
                    onChange={onChangeFunction}
                  />
                  <p className="rangeVals">20</p>
                </div>
              </div>
              <div className="formFields">
                <p>
                  2. The average number of interviews needed to make a hire, per
                  job
                </p>
                <div className="rangeSlider">
                  <p className="rangeVals">0</p>
                  <Slider
                    aria-label="Always visible"
                    defaultValue={numOfInterviewDefault}
                    step={1}
                    valueLabelDisplay="on"
                    size="small"
                    min={0}
                    max={30}
                    name="numOfInterview"
                    onChange={onChangeFunction}
                    valueLabelFormat={valueLabelFormat(
                      '',
                      inputObject.numOfInterview,
                      '',
                    )}
                  />
                  <p className="rangeVals">30</p>
                </div>
              </div>
              <div className="formFields">
                <p>
                  3. The estimated percentage of recruiter's time spent purely
                  on sourcing
                </p>
                <div className="rangeSlider">
                  <p className="rangeVals">0%</p>
                  <Slider
                    aria-label="Always visible"
                    defaultValue={percentageDefault}
                    step={1}
                    valueLabelDisplay="on"
                    size="small"
                    min={0}
                    max={100}
                    name="percentage"
                    onChange={onChangeFunction}
                    valueLabelFormat={valueLabelFormat(
                      '',
                      inputObject.percentage,
                      '%',
                    )}
                  />
                  <p className="rangeVals">100%</p>
                </div>
              </div>
              <div className="formFields">
                <p>
                  4. The annual license fees (per recruiter) paid for tools used
                  for sourcing (e.g. LinkedIn)
                </p>
                <div className="rangeSlider">
                  <p className="rangeVals">$1k</p>
                  <Slider
                    aria-label="Always visible"
                    defaultValue={linkedinDefault}
                    step={1}
                    valueLabelDisplay="on"
                    size="small"
                    min={0}
                    max={20}
                    name="annualFees"
                    onChange={onChangeFunction}
                    valueLabelFormat={valueLabelFormat(
                      '$',
                      inputObject.annualFees,
                      'K',
                    )}
                  />
                  <p className="rangeVals">$20k</p>
                </div>
              </div>
              <div className="inputFields">
                <div className="inptLeft">
                  <p>
                    5. The average recruiter/sourcer gross annual salary
                    {/* <a
                      href="https://www.indeed.com/career/talent-acquisition-sourcer/salaries"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Explore salary survey
                    </a> */}
                  </p>
                </div>
                <div className="inpRight">
                  <p>$</p>
                  <input
                    type="number"
                    name="annualSalary"
                    onChange={onChangeFunction}
                    required
                    value={inputObject.annualSalary}
                    placeholder="Type here"
                  />
                </div>
              </div>
              <div className="inputFields">
                <div className="inptLeft">
                  <p>6. The estimated job openings for the company per year</p>
                  <div className="toolTip">
                    <Tooltip title="This will help us estimate the total company sourcing costs">
                      {/* <img src={info} alt="..." /> */}
                      <p className="iTab">i</p>
                    </Tooltip>
                  </div>
                </div>
                <div className="inpRight inp2Right">
                  <input
                    type="number"
                    name="estimatedJob"
                    onChange={onChangeFunction}
                    required
                    placeholder="Example : 100"
                    value={inputObject.estimatedJob}
                  />
                </div>
              </div>
              {showFields ? (
                <div>
                  <div className="inputFields">
                    <div className="inptLeft">
                      <p>7. % of benefits cost</p>
                    </div>
                    <div className="inpRight">
                      <p>%</p>
                      <input
                        type="number"
                        name="benefit"
                        onChange={onChangeFunction}
                        required
                        value={inputObject.benefit}
                        placeholder="Type here"
                      />
                    </div>
                  </div>
                  <div className="inputFields">
                    <div className="inptLeft">
                      <p>8. % of management cost</p>
                    </div>
                    <div className="inpRight">
                      <p>%</p>
                      <input
                        type="number"
                        name="manageCost"
                        onChange={onChangeFunction}
                        required
                        value={inputObject.manageCost}
                        placeholder="Type here"
                      />
                    </div>
                  </div>
                  <div className="inputFields">
                    <div className="inptLeft">
                      <p>9. % of Office & Overhead cost</p>
                    </div>
                    <div className="inpRight">
                      <p>%</p>
                      <input
                        type="number"
                        name="overHead"
                        onChange={onChangeFunction}
                        required
                        value={inputObject.overHead}
                        placeholder="Type here"
                      />
                    </div>
                  </div>
                </div>
              ) : null}
              {showButton ? (
                <div className="rsltBtn">
                  {errorMsg ? (
                    <p className="errMsg">
                      Please fill all the slider's fields otherwise you cannot
                      continue
                    </p>
                  ) : null}
                  <button className="linkBtn" type="submit">
                    View Result <img src={Arrow} alt="..." />{' '}
                  </button>
                </div>
              ) : null}
            </form>
          </div>
        </div>
        {children}
      </div>
    </div>
  )
}

export default CalculateCard
