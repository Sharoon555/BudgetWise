import React from 'react'
import logo from '../../assets/logo-1 1.png'
import stars from '../../assets/Group 5455.png'
import emailGirl from '../../assets/Group 5473.png'
import emailStars from '../../assets/Group 5474.png'
import whiteStar from '../../assets/Mask group.png'
import yellow from '../../assets/Vector 12.png'
import { Link } from 'react-router-dom'

import './calBack.css'

const CalculatorBack = ({ children, head, para, emailImg, demoBtn }) => {
  return (
    <div className="calBackContainer">
      <div className="calBackSection">
        <div className="calBackContent">
          <div className="logoHeaed">
            <div className="scLogo">
              <Link to="/">
                <img src={logo} alt="..." />
              </Link>
              {demoBtn ? (
                <a
                  href=""
                  className="ylBtn"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Request a demo
                </a>
              ) : null}
            </div>
          </div>
          <div className="calBackHead">
            <div className="cbHead">
              <img src={stars} alt="..." />
              <h2>{head}</h2>
              <p>{para}</p>
            </div>
          </div>
          <div className="calculationBody">
            <div className="calculateBodyContent">
              {emailImg ? (
                <img className="emStar" src={emailStars} alt="..." />
              ) : (
                <img className="wtStar" src={whiteStar} alt="..." />
              )}
              <div className="calcCard">{children}</div>
              {emailImg ? (
                <img className="emlGirlImg" src={emailGirl} alt="..." />
              ) : (
                <img className="ylStar" src={yellow} alt="..." />
              )}
              <div className="cpRight">
                <p>All rights reserved to BudgetWise</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CalculatorBack
