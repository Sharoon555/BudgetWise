import React,{useEffect} from "react";
import CalculatorBack from "../../Components/calculatorBack/calculatorBack";
import "./result.css";
import ResultCard from "./ResultCard";


const CostResult = () => {

  useEffect(()=>{
    window.scrollTo(0,0)
},[])

  return (
    <div>
      <CalculatorBack
        head="How much does your recruitment cost?"
        children={<ResultCard />}
      />
    </div>
  );
};

export default CostResult;
