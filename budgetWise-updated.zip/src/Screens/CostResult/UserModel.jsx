import * as React from 'react'
import Button from '@mui/material/Button'
import Dialog from '@mui/material/Dialog'
import Slide from '@mui/material/Slide'
import { useFormik } from 'formik'
import * as Yup from 'yup'
import { useNavigate } from 'react-router-dom'
import cross from '../../assets/Group 5401.png'
import emailjs from '@emailjs/browser'

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />
})

export default function UserModel({ emailData, setSnackBar = () => {} }) {
  const navigate = useNavigate()
  // let regex = `(^[a-zA-Z0-9.%+-]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)(?!yahoo.co.in)(?!aol.com)(?!live.com)(?!outlook.com)[a-zA-Z0-9-]+.[a-zA-Z0-9-.]{2,61}$)`
  const formik = useFormik({
    initialValues: {
      name: '',
      companyName: '',
      email: '',
    },
    onSubmit: (values) => {
      // console.log(values);
      handleSendEmail(
        values.name[0].toUpperCase() + values.name.slice(1),
        values.companyName[0].toUpperCase() + values.companyName.slice(1),
        values.email,
      )
      
    },
    validationSchema: Yup.object().shape({
      name: Yup.string()
        .min(2, 'Too short')
        .required('Pleas Enter Your Full Name '),
      email: Yup.string()
        .email('Invalid email')
        .required('Your Email Must Be a Business Email Only'),
      companyName: Yup.string()
        .min(3, 'Too short')
        .required('Pleas Enter Your Company Name '),
    }),
  })
  const [open, setOpen] = React.useState(false)

  const handleClickOpen = () => {
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
  }

  const handleSendEmail = (name, companyName, email) => {
    // console.log(emailData)
    let emailObject = {
      to: 'sharoontariq555@gmail.com',
      to_name: name,
      from_Username: 'BudgetWise',
      user_name: name,
      company_name: companyName,
      email: email,
      roles: emailData.inputValues.roles,
      numberOfInterview: emailData.inputValues.numOfInterview,
      percentage: ` ${emailData.inputValues.percentage}%`,
      linkedin: `$${emailData.inputValues.annualFees}K`,
      salary: emailData.inputValues.annualSalary
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ','),
      opening: emailData.inputValues.estimatedJob,
      interview_without_talenya: emailData.totalCostPerInterview,
      jobCost_without_talenya: emailData.costPerRecruiterPerJob
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ','),
      annual_without_talenya: emailData.companyAnnualSourcingCost
        .toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ','),
      interview_with_talenya: emailData.TalenyaCostPerInterview.toString().replace(
        /\B(?=(\d{3})+(?!\d))/g,
        ',',
      ),
      jobCost_with_talenya: emailData.TalenyaSourcingCostPerJob.toString().replace(
        /\B(?=(\d{3})+(?!\d))/g,
        ',',
      ),
      annual_with_talenya: emailData.AnnualSourcingCostWithTalenya.toString().replace(
        /\B(?=(\d{3})+(?!\d))/g,
        ',',
      ),
    }
    // console.log(emailObject)
    emailjs
      .send(
        'service_fe8dge7',
        'template_2a8dlxk',
        emailObject,
        'VW-qXiXdrr61H3IO7',
      )
      .then(
        (result) => {
          console.log(result.text)
        },
        (error) => {
          console.log(error.text)
        },
      )
    //
    emailjs
      .send(
        'service_fe8dge7',
        'template_2a8dlxk',
        {
          ...emailObject,
          to: email,
          to_name: name,
          from_name: 'BudgetWise',
          subject: "BudgetWise's Calculator",
        },
        'VW-qXiXdrr61H3IO7',
      )
      .then(
        (result) => {
          console.log(result.text)
        },
        (error) => {
          console.log(error.text)
        },
      )
      setSnackBar(true)
      handleClose()
      setTimeout(() => {
        navigate('/interactive-calculator', { state: emailData })
      }, 1500)
  }


  // const handleUserForm = (e) => {
  //   e.preventDefault()
  // }

  return (
    <>
    <div>
      <button className="linkBtn" type="button" onClick={handleClickOpen}>
        View the interactive calculator
      </button>
      <Dialog
        open={open}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose}
        aria-describedby="alert-dialog-slide-description"
      >
        <div className="closeBtn">
          <Button onClick={handleClose}>
            <img src={cross} alt="..." />
          </Button>
        </div>
        <div className="modelHead">
          <h2>Fill your details below and we’ll send you the full report</h2>
        </div>
        <div className="modelBody">
          <form className="userForm" onSubmit={formik.handleSubmit}>
            <div className="userField">
              <p>NAME:</p>
              <input
                type="text"
                onChange={formik.handleChange}
                name="name"
                placeholder="Full Name"
                value={formik.values.name}
              />
              {formik.errors.name && formik.touched.name ? (
                <div className="errorMsg">{formik.errors.name} </div>
              ) : null}
            </div>
            <div className="userField">
              <p>COMPANY:</p>
              <input
                type="text"
                placeholder="Company Name"
                onChange={formik.handleChange}
                name="companyName"
                value={formik.values.companyName}
              />
              {formik.errors.companyName && formik.touched.companyName ? (
                <div className="errorMsg">{formik.errors.companyName} </div>
              ) : null}
            </div>
            <div className="userField">
              <p>BUSINESS E-MAIL:</p>
              <input
                type="email"
                placeholder="Your Business Email Address"
                onChange={formik.handleChange}
                name="email"
                value={formik.values.email}
                pattern="^[a-zA-Z0-9._%+-]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)(?!yahoo.co.in)(?!aol.com)(?!live.com)(?!outlook.com)(?!protonmail.com)(?!hubspot.com)(?!yandex.com)(?!lycos.com)(?!mail.com)(?!gmx.com)(?!tutanota.com)(?!zoho.com)(?!me.com)(?!012.com)(?!bezeqint.com)(?!msn.com)(?!ymail.com)(?!icloud.com)(?!inbox.com)(?!netvision.com)(?!googlemail.com)(?!mailsac.com)(?!terra.com.br)(?!terra.com)(?!walla.co.il.com)(?!mac.com)(?!mail.com)(?!ProtonMail.com)(?!zahav.net.il)(?!uol.com.br)(?!earthlink.net)(?!walla.com)(?!walla.co.il)[a-zA-Z0-9_-]+.[a-zA-Z0-9-.]{2,61}$"
              />
              {formik.errors.email && formik.touched.email ? (
                <div className="errorMsg">{formik.errors.email} </div>
              ) : null}
            </div>
            <div className="btnDiv">
              <button className="linkBtn" type="submit">
                View the interactive calculator
              </button>
            </div>
          </form>
        </div>
      </Dialog>
    </div>
    </>
  )
}
