import React, { useEffect, useState } from 'react'
import ResultTable from '../../Components/ResultTable/ResultTable'
import UserModel from './UserModel'
import { useLocation, useNavigate } from 'react-router-dom'
import { Alert, Snackbar } from '@mui/material'

const ResultCard = () => {
  let location = useLocation()
  const navigate = useNavigate()
  const [snackBar, setSnackBar] = useState(false)

  useEffect(() => {
    let locationState = location.state
    if (!locationState) {
      navigate('/cost-calculate')
    }
  }, [])
  const resetState = () => {
    navigate('/cost-calculate')
  }

  const handleCloseSnackBar = () => {
    setSnackBar(false)
  }

  return (
    <div className="rsCardContainer">
      <div className="rsCardContent">
        <div className="rsCardSection">
          <ResultTable locationData={location.state} />
          <div className="rsDetails">
            <div className="rsInfoPara">
              <p>
                Our analysis shows that you can save{' '}
                {location.state?.savingPercent}% of your cost for jobs sourced
                by BudgetWise's AI. Click to view and modify the parameters of the
                ROI model
              </p>
            </div>
            <div className="btnDiv">
              <UserModel emailData={location.state} setSnackBar={setSnackBar} />
            </div>
            {/* <div className="linkTag">
              <a
                href="/"
                target="_blank"
                rel="noopener noreferrer"
                onClick={resetState}
              >
                Learn more about BudgetWise
              </a>
            </div> */}
          </div>
        </div>
      </div>
      <Snackbar
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
        open={snackBar}
        onClose={handleCloseSnackBar}
        message="Report has been sent to your email!"
        autoHideDuration={3500}
      ><Alert severity="success">Report has been sent to your email!</Alert></Snackbar>
    </div>
  )
}

export default ResultCard
