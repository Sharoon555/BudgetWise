import React from "react";
import logo from "../../assets/logo.png";
import { Link } from "react-router-dom";
import Arrow from "../../assets/Arrow.png";
import rightImg from "../../assets/Group 5472.png";
import "./Main.css";

const MainScreen = () => {
  return (
    <div className="msContainer">
      <div className="msContent">
        <div className="msSection">
          <div className="msLogo">
            <Link to="/">
              <img src={logo} alt="logo" />
            </Link>
          </div>
          <div className="msDtl">
            <div className="msLeft">
              <h1>How much do you spend to get an interview?</h1>
              <Link to="/cost-calculate" className="linkBtn">
                Find Out <img src={Arrow} alt="..." />
              </Link>
            </div>
            <div className="msRight">
              <img src={rightImg} alt="..." />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainScreen;
