import React,{useEffect} from 'react'
import CalculatorBack from '../../Components/calculatorBack/calculatorBack'
import EmailCard from './emailCard'
import './email.css'

const EmailScreen = () => {

  useEffect(()=>{
    window.scrollTo(0,0)
},[])

  return (
    <div>
        <CalculatorBack 
         head='Where should we send your report?'
         emailImg
        children={<EmailCard />} />
    </div>
  )
}

export default EmailScreen