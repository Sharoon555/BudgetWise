import React, { useEffect, useState } from 'react'
import Arrow from '../../assets/Arrow.png'
import { useNavigate,useLocation } from 'react-router-dom'

const EmailCard = () => {
  const navigate = useNavigate()
  const location = useLocation()
  let [calculatorData , setCalculatorData] = useState(null)
  // console.log('location',location,calculatorData)

  useEffect(()=>{
      let locationState = location.state
      setCalculatorData(locationState)
      if(locationState=== null){
        navigate('/cost-calculate')
      }
  },[])

  let [email , setEmail] = useState('')
  let [emailError , setEmailError] = useState(false)
  const regex = "^[a-zA-Z0-9._%+-]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)(?!yahoo.co.in)(?!aol.com)(?!live.com)(?!outlook.com)(?!protonmail.com)(?!hubspot.com)(?!yandex.com)(?!lycos.com)(?!mail.com)(?!gmx.com)(?!tutanota.com)(?!zoho.com)(?!me.com)(?!012.com)(?!bezeqint.com)(?!msn.com)(?!ymail.com)(?!icloud.com)(?!inbox.com)(?!netvision.com)(?!googlemail.com)(?!mailsac.com)(?!terra.com.br)(?!terra.com)(?!walla.co.il.com)(?!mac.com)(?!mail.com)(?!ProtonMail.com)(?!zahav.net.il)(?!uol.com.br)(?!earthlink.net)(?!walla.com)(?!walla.co.il)[a-zA-Z0-9_-]+.[a-zA-Z0-9-.]{2,61}$";
  const handleEmail = (e)=>{
    setEmail(e.target.value)
  }
  const handleEmailSubmit = (e) => {
    // if(email.match(regex)){
      setEmailError(false)
    //  console.log('done')
     navigate('/cost-interview-result',{state : calculatorData})
    // }else{
    //   setEmailError(true)
    // }
    e.preventDefault()
  }
  return (
    <div className="calcCardContainer emailCrdContainer">
      <div className="emCardSection">
        <div className="emCardContent">
          <form className="emailForm" onSubmit={handleEmailSubmit}>
            <div className="emailField">
              <p>Enter email adress:</p>
              <input
                type="email"
                placeholder="Example: Email@email.com"
                // pattern="^[a-zA-Z0-9._%+-]+@(?!gmail.com)(?!yahoo.com)(?!hotmail.com)(?!yahoo.co.in)(?!aol.com)(?!live.com)(?!outlook.com)[a-zA-Z0-9_-]+.[a-zA-Z0-9-.]{2,61}$"
                required
                onChange={handleEmail}
              />
            </div>
            {emailError? 
            <div className="errorMsg">Your Email Must Be a Business Email Only </div>
            : null }
            <div className="emlBtn">
              <button className="linkBtn" type="submit">
                Show me my results <img src={Arrow} alt="..." />{' '}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default EmailCard
