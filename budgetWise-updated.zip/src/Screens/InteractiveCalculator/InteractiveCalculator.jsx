import React, { useState, useEffect } from 'react'
import CalculateCard from '../../Components/CalculateCard/CalculateCard'
import CalculatorBack from '../../Components/calculatorBack/calculatorBack'
// import { useNavigate } from 'react-router-dom'

import './interactive.css'
import ResultTable from '../../Components/ResultTable/ResultTable'
import { useLocation } from 'react-router-dom'
import UserModel from '../CostResult/UserModel'
import { Alert, Snackbar } from '@mui/material'

const calculateValues = {
  roles: 0,
  numOfInterview: 0,
  percentage: 0,
  annualFees: 0,
  annualSalary: '',
  estimatedJob: '',
  overHead: '',
  manageCost: '',
  benefit: '',
}

const InteractiveCalculator = () => {
  const location = useLocation()
  let [inputValues, setInputValues] = useState(calculateValues)
  let [roiData, setRoi] = useState(null)
  let [tableData, setTableData] = useState()
  const [snackBar, setSnackBar] = useState(false)

  const handleChange = async (e) => {
    setInputValues({ ...inputValues, [e.target.name]: e.target.value })
  }

  useEffect(() => {
    let locationData = location.state;

    if (location.state) {

      setInputValues(locationData.inputValues)
    }
    else {
      setInputValues(calculateValues)
    }
  }, [])

  // run if state change 
  useEffect(() => {
    handleResult()
  }, [inputValues])

  const handleResult = () => {
    // console.log(inputValues)
    if (
      inputValues.roles > 0 &&
      inputValues.numOfInterview > 0 &&
      inputValues.percentage > 0 &&
      inputValues.annualFees > 0
    ) {
      let hiresPerRecruiterPerYear = inputValues.roles * 12
      let recruiterFullyLoadedAnnualCost =
        Number(inputValues.annualSalary) +
        Number(inputValues.annualSalary) * (Number(inputValues.benefit) / 100) +
        Number(inputValues.annualSalary) *
        (Number(inputValues.manageCost) / 100) +
        Number(inputValues.annualSalary) * (Number(inputValues.overHead) / 100)
      let sourcingLaborCost =
        recruiterFullyLoadedAnnualCost * (inputValues.percentage / 100)
      let costOfSourcingPerRecruiter =
        sourcingLaborCost + inputValues.annualFees * 1000
      let costPerRecruiterPerJob =
        costOfSourcingPerRecruiter / hiresPerRecruiterPerYear
      let TotalAnnualOpenings = inputValues.estimatedJob
      let totalCostPerInterview = Math.round(
        costPerRecruiterPerJob / inputValues.numOfInterview,
      )
      let companyAnnualSourcingCost = Math.round(
        TotalAnnualOpenings * costPerRecruiterPerJob,
      )
      let TalenyaSourcingCostPerJob = 250
      let TalenyaInterviewsPerJob = 5
      let TalenyaCostPerInterview =
        TalenyaSourcingCostPerJob / TalenyaInterviewsPerJob
      let AnnualSourcingCostWithTalenya =
        TalenyaSourcingCostPerJob * Number(inputValues.estimatedJob)
      let AnnualSavingsWithTalenya =
        companyAnnualSourcingCost - AnnualSourcingCostWithTalenya
      let savingPercent =
        (1 - AnnualSourcingCostWithTalenya / recruiterFullyLoadedAnnualCost) *
        100
      let Roi = 12 / (AnnualSavingsWithTalenya / AnnualSourcingCostWithTalenya)
      let savingInterviewPerJob =
        totalCostPerInterview - TalenyaCostPerInterview
      let savingPercentagePerInterviewPerJob = Math.round(
        (savingInterviewPerJob / totalCostPerInterview) * 100,
      )
      let SavingPerJobWithTalenya =
        costPerRecruiterPerJob - TalenyaSourcingCostPerJob
      let SavingPerJobPercentageWithTalenya =
        SavingPerJobWithTalenya / costPerRecruiterPerJob

      // let AnnualSavingsWithTalenya =
      //   companyAnnualSourcingCost - AnnualSourcingCostWithTalenya
      let percentageOfAnnualSourcingCost =
        AnnualSavingsWithTalenya / companyAnnualSourcingCost
      setRoi(Roi.toFixed(1))

      //  console.log(Roi)
      const dataObj = {
        totalCostPerInterview,
        companyAnnualSourcingCost,
        costPerRecruiterPerJob: Math.round(costPerRecruiterPerJob),
        TalenyaCostPerInterview,
        TalenyaSourcingCostPerJob,
        AnnualSourcingCostWithTalenya,
        savingPercent: Math.round(percentageOfAnnualSourcingCost * 100),
        SavingPerJobPercentageWithTalenya: Math.round(
          SavingPerJobPercentageWithTalenya * 100,
        ),
        savingPercentagePerInterviewPerJob,
      }
      setTableData(dataObj)
    }
  }

  
  const handleCloseSnackBar = () => {
    setSnackBar(false)
  }

  // console.log(roiData)
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div>
      <CalculatorBack
        head="BudgetWise’s Calculator"
        para="Calculate your recruitment costs "
        // demoBtn
        children={
          <div>
            <CalculateCard
              inputObject={inputValues}
              onChangeFunction={handleChange}
              showFields
              classname="intActiveCard"
              className2="intActiveContent"
              roleDefault={location.state?.inputValues?.roles}
              numOfInterviewDefault={location.state?.inputValues?.numOfInterview}
              percentageDefault={location.state?.inputValues?.percentage}
              linkedinDefault={location.state?.inputValues?.annualFees}
              children={
                <div className="interactiveTable">
                  <ResultTable locationData={tableData} />
                  <div className="roi">
                    <p>ROI (in months)</p>
                    <p className="roiVal">{roiData >= 0 || roiData <= 0 ? roiData : 0}</p>
                  </div>
                  <div className="btnDiv">
                    <UserModel emailData={location.state} setSnackBar={setSnackBar} />
                  </div>
                  <br />
                  <br />
                </div>
              }
            />

          </div>
        }
      />
      <Snackbar
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
        open={snackBar}
        onClose={handleCloseSnackBar}
        message="Report has been sent to your email!"
        autoHideDuration={3500}
      ><Alert severity="success">Report has been sent to your email!</Alert></Snackbar>
    </div>
  )
}

export default InteractiveCalculator
