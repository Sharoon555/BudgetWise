import React, { useState, useEffect } from 'react'
import CalculateCard from '../../Components/CalculateCard/CalculateCard'
import CalculatorBack from '../../Components/calculatorBack/calculatorBack'
import { Link, useNavigate } from 'react-router-dom'

import './cost.css'

const calculateValues = {
  roles: 5,
  numOfInterview: 9,
  percentage: 40,
  annualFees: 8,
  annualSalary: '',
  estimatedJob: '',
  overHead: 5,
  manageCost: 15,
  benefit: 17,
}

const CostCalculator = () => {
  const navigate = useNavigate()

  let [inputValues, setInputValues] = useState(calculateValues)
  let [errorMsg, setErrorMsg] = useState(false)
  const handleChange = (e) => {
    setInputValues({ ...inputValues, [e.target.name]: e.target.value })
  }

  const handleSubmitForCost = (e) => {
    e.preventDefault()
    if (
      inputValues.roles > 0 &&
      inputValues.numOfInterview > 0 &&
      inputValues.percentage > 0 &&
      inputValues.annualFees > 0
    ) {
      setErrorMsg(false)
      let hiresPerRecruiterPerYear = inputValues.roles * 12
      let recruiterFullyLoadedAnnualCost =
        Number(inputValues.annualSalary) +
        Number(inputValues.annualSalary) * 0.17 +
        Number(inputValues.annualSalary) * 0.15 +
        Number(inputValues.annualSalary) * 0.05
      let sourcingLaborCost =
        recruiterFullyLoadedAnnualCost * (inputValues.percentage / 100)
      let costOfSourcingPerRecruiter =
        sourcingLaborCost + inputValues.annualFees * 1000
      let costPerRecruiterPerJob =
        costOfSourcingPerRecruiter / hiresPerRecruiterPerYear
      let TotalAnnualOpenings = inputValues.estimatedJob
      let totalCostPerInterview = Math.round(
        costPerRecruiterPerJob / inputValues.numOfInterview,
      )
      let companyAnnualSourcingCost = Math.round(
        TotalAnnualOpenings * costPerRecruiterPerJob,
      )
      let TalenyaSourcingCostPerJob = 250
      let TalenyaInterviewsPerJob = 5
      let TalenyaCostPerInterview =
        TalenyaSourcingCostPerJob / TalenyaInterviewsPerJob
      let AnnualSourcingCostWithTalenya =
        TalenyaSourcingCostPerJob * Number(inputValues.estimatedJob)
      let AnnualSavingsWithTalenya =
        companyAnnualSourcingCost - AnnualSourcingCostWithTalenya
      let percentageOfAnnualSourcingCost =
        AnnualSavingsWithTalenya / companyAnnualSourcingCost
      let SavingPerJobWithTalenya =
        costPerRecruiterPerJob - TalenyaSourcingCostPerJob
      let SavingPerJobPercentageWithTalenya =
        SavingPerJobWithTalenya / costPerRecruiterPerJob
      let savingPercent =
        (100 / 100 -
          AnnualSourcingCostWithTalenya / recruiterFullyLoadedAnnualCost) *
        100
      let savingInterviewPerJob =
        totalCostPerInterview - TalenyaCostPerInterview

      let savingPercentagePerInterviewPerJob = Math.round(
        (savingInterviewPerJob / totalCostPerInterview) * 100,
      )

      const dataObj = {
        totalCostPerInterview,
        companyAnnualSourcingCost,
        costPerRecruiterPerJob: Math.round(costPerRecruiterPerJob),
        TalenyaCostPerInterview,
        TalenyaSourcingCostPerJob,
        AnnualSourcingCostWithTalenya,
        savingPercent: Math.round(percentageOfAnnualSourcingCost * 100),
        SavingPerJobPercentageWithTalenya: Math.round(
          SavingPerJobPercentageWithTalenya * 100,
        ),
        savingPercentagePerInterviewPerJob,
        inputValues,
      }
      // navigate('/email-to-cost', { state: dataObj })
      navigate('/cost-interview-result',{state : dataObj})
    } else {
      setErrorMsg(true)
    }
  }

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div>
      <CalculatorBack
        head="We’ll make it fast & simple"
        para="Please provide information on 6 topics and we’ll calculate your costs"
        children={
          <CalculateCard
            inputObject={inputValues}
            onChangeFunction={handleChange}
            handleSubmit={handleSubmitForCost}
            showButton
            arrowImage
            roleDefault={5}
            numOfInterviewDefault={9}
            percentageDefault={40}
            linkedinDefault={8}
            errorMsg={errorMsg}
          />
        }
      />
    </div>
  )
}

export default CostCalculator
